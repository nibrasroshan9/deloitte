package com.pms.deloitte.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.pms.deloitte.dao.ProductDAO;
import com.pms.deloitte.model.Product;
import com.pms.deloitte.service.ProductService;

@Controller
public class ProductController {
	@Autowired
	ProductService productService;
	
	@RequestMapping("saveProduct")
	public ModelAndView saveProduct(Product product ) {
		ModelAndView view  = new ModelAndView("redirect:/ProductForm");
		productService.addProduct(product);
		return view;
	}
	@RequestMapping("deleteProduct/{prodId}")
	public ModelAndView deleteProduct(@PathVariable("prodId")Integer productId) {
		ModelAndView view  = new ModelAndView("redirect:/ProductForm");
		productService.deleteProduct(productId);;
		return view;
	}
	@RequestMapping("editProduct/add/update")
	public String updateProduct(Product product) {
		this.productService.updateProduct(product);
		return "redirect:/ProductForm";
	}
	@RequestMapping("editProduct/{prodId}")
	public ModelAndView editProduct(@PathVariable("prodId")Integer productId) {
		Product product = productService.getProduct(productId);
		ModelAndView view  = new ModelAndView("product");
		List<Product> allProducts = productService.listProducts();
		view.addObject("allProducts",allProducts);
		view.addObject("product", product);
		return view;
	}

	@RequestMapping("ProductForm")
	public ModelAndView formLoad() {
		ModelAndView view  = new ModelAndView("product");
		List<Product> allProducts = productService.listProducts();
		view.addObject("allProducts",allProducts);
		view.addObject("product",new Product());
		return view;
	}
}
