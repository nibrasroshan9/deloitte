package com.pms.deloitte.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ProductController {
	
	@RequestMapping("saveProduct")
	public ModelAndView saveProduct() {
		ModelAndView view  = new ModelAndView("saveProduct");
		return view;
	}
	@RequestMapping("deleteProduct")
	public ModelAndView deleteProduct() {
		ModelAndView view  = new ModelAndView("deleteProduct");
		return view;
	}
	@RequestMapping("updateProduct")
	public ModelAndView updateProduct() {
		ModelAndView view  = new ModelAndView("updateProduct");
		return view;
	}
}
