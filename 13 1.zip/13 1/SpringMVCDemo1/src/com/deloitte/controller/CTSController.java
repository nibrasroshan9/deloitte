package com.deloitte.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CTSController {

	@RequestMapping("/ahmed")
	public String gg(){
		return "ghosia";
	}
	@RequestMapping("/Product")
	public String gaaga(){
		return "product";
	}
	@RequestMapping("/Customer")
	public String gaag(){
		return "cust";
	}
	@RequestMapping("/name")
	public String galag(){
		return "name";
	}
	@RequestMapping("/guest")
	public String galage(){
		return "guest";
	}
	@RequestMapping("/customsave")
	public String galagel(){
		return "save";
	}
}
