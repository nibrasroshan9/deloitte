package com.cms.deloitte.service;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cms.deloitte.dao.CustomerDAO;
import com.cms.deloitte.dao.impl.CustomerDAOImpl;
import com.cms.deloitte.model.Customer;

/**
 * Servlet implementation class CustomerService
 */
public class CustomerService implements CustomerServiceI{
	private static final long serialVersionUID = 1L;
	CustomerDAO customerDAO = new CustomerDAOImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustomerService() {
        super();
        // TODO Auto-generated constructor stub
    }



	@Override
	public boolean addCustomer(Customer customer) {
		if(customer.getBillAmount()>0) {
			customerDAO.addCustomer(customer);
			return true;
		}
		return false;
	}

	@Override
	public boolean updateCustomer(Customer customer) {
		if(customer.getBillAmount()>0) {
			customerDAO.updateCustomer(customer);
			return true;
		}
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Customer> listCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer findCustomer(int customerId) {
		return customerDAO.findCustomer(customerId);
	}

	@Override
	public boolean isCustomerExists(int customerId) {
		// TODO Auto-generated method stub
		return false;
	}
	}
