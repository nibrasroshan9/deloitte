package com;

import org.springframework.beans.factory.annotation.Autowired;

public class ToEmail {
	private String toName;
	private String toEmailId;
	public ToEmail() {
		super();
	}
	public ToEmail(String toName, String toEmailId) {
		super();
		this.toName = toName;
		this.toEmailId = toEmailId;
	}
	public String getToName() {
		return toName;
	}
	public void setToName(String toName) {
		this.toName = toName;
	}
	public String getToEmailId() {
		return toEmailId;
	}
	public void setToEmailId(String toEmailId) {
		this.toEmailId = toEmailId;
	}
	@Override
	public String toString() {
		return "ToEmail [toName=" + toName + ", toEmailId=" + toEmailId + "]";
	}
	
}
