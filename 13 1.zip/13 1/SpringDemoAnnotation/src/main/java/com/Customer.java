package com;

import org.springframework.beans.factory.annotation.Autowired;
import javax.annotation.*;

public class Customer {
	private int customerId;
	private String customerName;
	private String customerAddress;
	private int billAmount;
	
	@Autowired
	private ContactDetails customerContact;
	
	public Customer(ContactDetails customerContact) {
		super();
		System.out.println("cust");
		this.customerContact = customerContact;
	}

	public Customer(int customerId, String customerName, String customerAddress, int billAmount,
			ContactDetails customerContact) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.billAmount = billAmount;
		this.customerContact = customerContact;
	}

	public ContactDetails getCustomerContact() {
		return customerContact;
	}

	public void setCustomerContact(ContactDetails customerContact) {
		this.customerContact = customerContact;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public int getBillAmount() {
		return billAmount;
	}

	public void setBillAmount(int billAmount) {
		this.billAmount = billAmount;
	}

	public Customer() {
		super();
	}

	public Customer(int customerId, String customerName, String customerAddress, int billAmount) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.billAmount = billAmount;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerAddress="
				+ customerAddress + ", billAmount=" + billAmount + ", customerContact=" + customerContact + "]";
	}
	@PostConstruct
	public void displayCust() {
		System.out.println("Cust disp called");
	}
	@PreDestroy
	public void cleanUpCust() {
		System.out.println("Clean cust called");
	}
	
}
