import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class DemoShortcut {

	public static void main(String[] args) throws IOException {
		BufferedReader rd = new BufferedReader(new FileReader(new File("mohan.txt")));
		BufferedWriter wt = new BufferedWriter(new FileWriter(new File("sharma.txt")));
		
		int i=0;
		while((i = rd.read())!=-1) {
			wt.append((char)i);
		}
		wt.close();
		rd.close();
	}

}
