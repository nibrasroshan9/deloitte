import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DeserializeInputDemo {
	public static void main(String[] args) throws IOException, ClassNotFoundException{
		Customer customer = new Customer();
		ObjectInputStream stream = new ObjectInputStream(new BufferedInputStream(new FileInputStream(new File("delu.txt"))));
		
		customer = (Customer)stream.readObject();
		
		stream.close();
		System.out.println(customer);
		System.out.println("Read");
		
	}
}
