import java.util.Scanner;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class FileCopyUserInput {

	public static void main(String[] args) throws IOException {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter source file : ");
		String src = in.next();
		File file = new File(src);


		while(!file.exists()) {
			System.out.println(src+" doesn't exist. Please select a valid file");
			src = in.next();
			file = new File(src);
		} 
		if(file.exists()) {
			System.out.println("Enter target file : ");
			String tgt = in.next();
			File file1 = new File(tgt);
			
			FileReader rd = new FileReader(file);
			FileWriter fw = new FileWriter(file1);
			int i = 0;
			while ((i = rd.read()) != (-1)) {
				fw.append((char) i);
			}
			rd.close();
			fw.close();
			System.out.println(file+" successfully copied to "+file1);
		}
		in.close();

	}

}
