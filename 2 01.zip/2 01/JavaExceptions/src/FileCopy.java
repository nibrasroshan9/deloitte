import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileCopy {

	public static void main(String[] args) throws IOException {
		File file = new File("record.txt");
		File file1 = new File("target.txt");

		if (!file.exists()) {
			System.out.println("File doesn't exist. Please select a valid file");
		} else {
			FileReader rd = new FileReader(file);
			FileWriter fw = new FileWriter(file1);
			int i = 0;
			while ((i = rd.read()) != (-1)) {
				fw.append((char) i);
			}
			rd.close();
			fw.close();
			FileReader rd1 = new FileReader(file1);
			int j = 0;
			while ((j = rd1.read()) != (-1)) {
				System.out.print((char) j);
			}
			rd1.close();
		}
	}

}
