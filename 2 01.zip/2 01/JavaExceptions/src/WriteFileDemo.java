import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class WriteFileDemo {
	public static void main(String[] args) throws IOException{
		File file = new File("record.txt");
		FileWriter fw = new FileWriter(file);
		fw.write("I am Nibras Roshan.");
		fw.close();
		FileReader rd = new FileReader(file);
		int i = 0;
		while((i=rd.read())!=(-1)) {
			System.out.print((char)i);
		}
		rd.close();
	}
}
