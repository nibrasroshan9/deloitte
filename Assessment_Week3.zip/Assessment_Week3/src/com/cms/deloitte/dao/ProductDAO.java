package com.cms.deloitte.dao;
import java.util.ArrayList;

import java.util.List;

import com.cms.deloitte.model.*;
import com.Product.*;

public interface ProductDAO {

	public boolean addProduct(Product Product);
	
}
