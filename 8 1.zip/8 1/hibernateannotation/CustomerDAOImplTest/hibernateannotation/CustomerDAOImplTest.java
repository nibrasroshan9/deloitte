package hibernateannotation;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.cms.deloitte.dao.CustomerDAO;
import com.cms.deloitte.dao.impl.CustomerDAOImpl;
import com.cms.deloitte.model.Customer;

class CustomerDAOImplTest {

	CustomerDAO customerdao = new CustomerDAOImpl();
	@Test
	void testFilterCustomerStringInt() {
		String customerAddress = "Capsule";
		int billAmount = 1000;
		List<String> allCustomers = customerdao.filterCustomer(customerAddress, billAmount);
		assertEquals(1, allCustomers.size());
	}

}
