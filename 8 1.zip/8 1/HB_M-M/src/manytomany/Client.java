package manytomany;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Client {
	public static void main(String[] args) {
		
		Configuration cfg = new Configuration().configure();
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		
		EmployeeDetails em1 = new EmployeeDetails(1019, "Dipam", 19000);
		EmployeeDetails em2 = new EmployeeDetails(1020, "Kavitha", 19500);
		AddressDetails add1 = new AddressDetails(111, "Pune", "MH");
		AddressDetails add2 = new AddressDetails(112, "Kochi", "KL");
		AddressDetails add3 = new AddressDetails(113, "Bangalore", "KA");
		AddressDetails add4 = new AddressDetails(114, "Puri", "OD");
		AddressDetails add5 = new AddressDetails(115, "Mumbai", "MH");
		AddressDetails add6 = new AddressDetails(116, "Chennai", "TN");
		
		Set addressSet1 = new HashSet<>();
		addressSet1.add(add1);
		addressSet1.add(add4);
		addressSet1.add(add5);
		
		Set addressSet2 = new HashSet<>();
		addressSet2.add(add2);
		addressSet2.add(add3);
		addressSet2.add(add6);
		
		em1.setEmployeeAddress(addressSet1);
		em2.setEmployeeAddress(addressSet2);
		
		Transaction transaction = session.beginTransaction();
		session.save(em1);
		session.save(em2);
		
		transaction.commit();
		
		System.out.println("Saved all the data");
	}
}
