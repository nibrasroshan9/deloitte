package manytomany;

import java.util.Set;

public class AddressDetails {
	private int addressId;
	private String cityName;
	private String stateName;

	public AddressDetails() {
		super();
	}

	public AddressDetails(int addressId, String cityName, String stateName) {
		super();
		this.addressId = addressId;
		this.cityName = cityName;
		this.stateName = stateName;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}


}
