package com.customtags;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class CustomNameTag extends TagSupport{
	private int noOfTimes = 5;
	private String name;
	
	public int getNoOfTimes() {
		return noOfTimes;
	}

	public void setNoOfTimes(int noOfTimes) {
		this.noOfTimes = noOfTimes;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int doStartTag() throws JspException{
		JspWriter out = pageContext.getOut();

		try {
			for(int i=0; i<noOfTimes; i++) {
				out.println("<br/>"+name);
			}
			
		}
		catch(IOException e){
			e.printStackTrace();
		}
		return super.doStartTag();
	}
}
