package com;

import java.sql.Connection;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Client {
	public static void main(String[] args) {
		Configuration cfg = new Configuration().configure();
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		
		Transaction tx = session.beginTransaction();
		
		RegularEmployee employee = new RegularEmployee(41000, 9000);
		employee.setEmployeeId(111);
		employee.setEmployeeName("Arjun");
		
		ContractEmployee employee1 = new ContractEmployee(20, 3000);
		employee1.setEmployeeId(112);
		employee1.setEmployeeName("Tufail");
		
		RegularEmployee employee2 = new RegularEmployee(41000, 15000);
		employee2.setEmployeeId(113);
		employee2.setEmployeeName("George");
		
		session.save(employee);
		session.save(employee1);
		tx.commit();
		session.close();
		System.out.println("Done.");
		factory.close();
	}

}
