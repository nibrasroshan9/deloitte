package com;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class SumTest {
	
	@Test
	void testAddNumbers() {
		Sum sum = new Sum();
		assertEquals(20, sum.addNumbers(19,1));
	}
}
