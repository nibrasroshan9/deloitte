package singletondemo;

public class Bank {
	public static void main(String[] args) {
		Payment pay1 = Payment.getPaymentObject();
		pay1.pay(100);
		Payment p2 = Payment.getPaymentObject();
		p2.pay(200000);
		Payment p3 = Payment.getPaymentObject();
		p3.pay(3500);
	}
}
