package singletondemo;

public class Payment {
	private Payment() {
		System.out.println("Memory allocated");
	}
	private static Payment pay = new Payment();
	
	public static Payment getPaymentObject() {
		return pay;
	}
	public void pay(int amt) {
		System.out.println("Paid "+amt);
	}
}
