package jdbcdemo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Main {

	public static void main(String[] args) throws SQLException {
		Customer c = new Customer();
		c.accept();
		
		Connection conn = DBconnection.makeConnection();
		PreparedStatement state = conn.prepareStatement("insert into hr.customer values(?,?,?,?)");
		state.setInt(1, c.getCustomerId());
		state.setString(2, c.getCustomerName());
		state.setString(3, c.getCustomerAddress());
		state.setInt(4, c.getBillAmount());
		
		state.executeUpdate();
		
		System.out.println(c.getCustomerName()+", your details have been succesfully entered");
	}

}
