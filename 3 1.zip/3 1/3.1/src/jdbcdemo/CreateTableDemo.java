package jdbcdemo;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateTableDemo {

	public static void main(String[] args) throws SQLException {
		Connection conn = DBconnection.makeConnection();
		Statement state = conn.createStatement();
		String query = "create table hr.salary(salary integer, bonus integer)";
		state.execute(query);
	}

}
