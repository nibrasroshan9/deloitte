package jdbcdemo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class InsertTableDemo {

	public static void main(String[] args) throws SQLException {
		Connection conn = DBconnection.makeConnection();
		Statement state = conn.createStatement();
		String insert = "insert into hr.customer values(1877,'Bibhu','Bhubneswar',5000)";
		int rowsChanged = state.executeUpdate(insert);
		System.out.println(rowsChanged + " rows were changed");
		Statement st1 = conn.createStatement();
		String sel = "select * from hr.customer";
		ResultSet res = st1.executeQuery(sel);
		while(res.next()) {
			System.out.print(res.getInt(1) + " ");
			System.out.print(res.getString(2) + " ");
			System.out.print(res.getString(3) + " ");
			System.out.println(res.getInt(4) + " ");
		}
	}

}
