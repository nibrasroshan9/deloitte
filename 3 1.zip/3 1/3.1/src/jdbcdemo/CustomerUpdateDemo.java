package jdbcdemo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CustomerUpdateDemo {

	public static void main(String[] args) throws SQLException {
		Customer c = new Customer();
		c.accept();
		Connection conn = DBconnection.makeConnection();
		PreparedStatement state = conn.prepareStatement("update hr.customer set customername=?,customeraddress=?,billamount=? where customerid=?");
		state.setString(1, c.getCustomerName());
		state.setString(2, c.getCustomerAddress());
		state.setInt(3, c.getBillAmount());
		state.setInt(4, c.getCustomerId());
		
		state.executeUpdate();
		System.out.println("Successfully updated");
	}

}
