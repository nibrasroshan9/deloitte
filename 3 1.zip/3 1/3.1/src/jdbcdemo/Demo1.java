package jdbcdemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Demo1 {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		//driver
		Class.forName("oracle.jdbc.driver.OracleDriver");
		System.out.println("Driver loaded");
		//conn
		Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:xe", "system", "admin");
		System.out.println("Connection established");
		//statements
		Statement stat = conn.createStatement();
		ResultSet res = stat.executeQuery("select * from hr.customer");
		
		while(res.next()) {
			System.out.print(res.getInt(1) + " ");
			System.out.print(res.getString(2) + " ");
			System.out.print(res.getString(3) + " ");
			System.out.println(res.getInt(4) + " ");
		}
		stat.close();
		conn.close();
		
	}
}
