import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class RandomDemo {

	public static void main(String[] args) throws IOException {
		RandomAccessFile file = new RandomAccessFile("friday.txt", "rw");
		file.writeUTF("Today is a friday");
		System.out.println(file.getFilePointer());
		file.seek(0);
		System.out.println(file.getFilePointer());
		
		String str = file.readUTF();
		
		
		System.out.println("File content is : ");
		System.out.println(str);
		
		file.seek((file.length()));
		System.out.println(file.getFilePointer());
		file.writeUTF("Nibras");
		
		file.seek(0);
		String str1 = file.readLine();
		System.out.println(str1);

		file.close();
	}

}
