package com.cms.deloitte.client;

import java.util.Scanner;

import com.cms.deloitte.dao.impl.CustomerDAOImpl;
import com.cms.deloitte.model.Customer;

public class LaunchCustomerApplication {
	public static void startCustomerApp() {
		System.out.println("Welcome to Customer App");
		System.out.println("1. Add customer");
		System.out.println("2. Update customer");
		System.out.println("3. Exit");
		
		Scanner in = new Scanner(System.in);
		System.out.println("Enter choice");
		int choice = in.nextInt();
		
		if(choice==1) {
			Customer c = new Customer();
			c.acceptCustomerDetails();
			CustomerDAOImpl impl = new CustomerDAOImpl();
			boolean result = impl.addCustomer(c);
			System.out.println(result);
		}
		else if (choice==2) {
			Customer c = new Customer();
			c.acceptCustomerDetails();
			CustomerDAOImpl impl = new CustomerDAOImpl();
			boolean result = impl.updateCustomer(c);
			System.out.println(result);
		}
		else if (choice==3) {
			System.out.println("Thank you for using the customer app");
			System.exit(0);
		}

		
	}
}
