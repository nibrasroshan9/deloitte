package com.cms.deloitte.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import com.cms.deloitte.dao.CustomerDAO;
import com.cms.deloitte.dbcon.DBConnection;
import com.cms.deloitte.model.Customer;

public class CustomerDAOImpl implements CustomerDAO{
	private static final String INSERT_CUSTOMER_QUERY = "insert into hr.customer values(?,?,?,?)";
	private static final String UPDATE_CUSTOMER_QUERY = "update hr.customer set (customername = ?, customeraddress = ?, billamount = ?) where customerid = ?";
	private static final String DELETE_CUSTOMER_QUERY = "delete from hr.customer where customerid=?";
	
	@Override
	public boolean addCustomer(Customer c) {
		Connection conn = DBConnection.makeConnection();
		int res = 0;
		try {
			PreparedStatement state = conn.prepareStatement(INSERT_CUSTOMER_QUERY);
			state.setInt(1, c.getCustomerId());
			state.setString(2, c.getCustomerName());
			state.setString(3, c.getCustomerAddress());
			state.setInt(4, c.getBillAmount());
			
			res = state.executeUpdate();
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		if(res==0)
			return false;
		else
			return true;
	}

	@Override
	public boolean updateCustomer(Customer c) {
		Connection conn = DBConnection.makeConnection();
		int res = 0;
		try {
			PreparedStatement state = conn.prepareStatement(UPDATE_CUSTOMER_QUERY);
			state.setInt(4, c.getCustomerId());
			state.setString(1, c.getCustomerName());
			state.setString(2, c.getCustomerAddress());
			state.setInt(3, c.getBillAmount());
			
			res = state.executeUpdate();
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		if(res==0)
			return false;
		else
			return true;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		Connection conn = DBConnection.makeConnection();
		int res = 0;
		try {
			PreparedStatement state = conn.prepareStatement(DELETE_CUSTOMER_QUERY);
			state.setInt(1, customerId);
			
			res = state.executeUpdate();
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(res==0)
			return false;
		else
			return true;
		
	}

	@Override
	public List<Customer> listCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer findCustomer(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isCustomerExists(int customerId) {
		// TODO Auto-generated method stub
		return false;
	}
	
	

}
