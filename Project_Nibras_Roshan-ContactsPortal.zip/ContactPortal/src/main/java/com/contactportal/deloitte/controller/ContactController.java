package com.contactportal.deloitte.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.servlet.ModelAndView;

import com.contactportal.deloitte.dao.AdminDAO;
import com.contactportal.deloitte.dao.UserDAO;
import com.contactportal.deloitte.model.Admin;
import com.contactportal.deloitte.model.Contact;
import com.contactportal.deloitte.model.User;
import com.contactportal.deloitte.service.ContactService;
import com.contactportal.deloitte.service.UserService;

@Controller

//@RequestMapping("contactPortal")

public class ContactController {

	@Autowired
	UserDAO userDAO;

	@Autowired
	AdminDAO adminDAO;
	
	
	@Autowired
	UserService userService;

	@Autowired
	ContactService contactService;

	@RequestMapping("/saveContact")

	public ModelAndView saveContact(Contact contact) {
		try {
		if(contact.getContactId()!=0) {
		ModelAndView view = new ModelAndView("redirect:/admin");

		view.addObject("contact", new Contact());

		contactService.addContact(contact);

//		System.out.println(contact);

		return view;
		}
		else {
			ModelAndView view = new ModelAndView("redirect:/admin");

			view.addObject("contact", new Contact());
			return view;

		}
		}
		catch (Exception e) {
			ModelAndView view = new ModelAndView("redirect:/admin");

			view.addObject("contact", new Contact());
			return view;
		}
		
	}
	

	@RequestMapping("/editContact/{contId}")

	public ModelAndView editContact(@PathVariable("contId") Integer userId) {

//		System.out.println("####### Contact Portal Controller editContact");

		ModelAndView view = new ModelAndView("adminForm");

		Contact contact = contactService.getContact(userId);

		List<Contact> allContacts = contactService.listContacts();

		view.addObject("contact", contact);

		view.addObject("allContacts", allContacts);
		int length=allContacts.size();
		view.addObject("length", length);

		return view;

	}

	@RequestMapping(value = "/editContact/add/update")

	public String updateContact(Contact contact) {

		contactService.updateContact(contact);

		return "redirect:/admin";

	}

	@RequestMapping("/deleteContact/{contId}")

	public ModelAndView deleteContact(@PathVariable("contId") Integer userId) {

		ModelAndView view = new ModelAndView("redirect:/admin");

		contactService.deleteContact(userId);

		return view;

	}

	@RequestMapping("/viewContact")

	public ModelAndView viewContact() {

		ModelAndView view = new ModelAndView("contactView");

		return view;

	}

	@RequestMapping("/contact")

	public ModelAndView contactPortal(Contact contact) {
		if(contact.getContactId()!=0) {
			ModelAndView view = new ModelAndView("userForm");

			view.addObject("contact", new Contact());

			List<Contact> allContacts = contactService.listContacts();
			view.addObject("allContacts", allContacts);
			System.out.println(allContacts);
			int length=allContacts.size();
			view.addObject("length", length);

			return view;
			}
			else {
				ModelAndView view = new ModelAndView("userForm");
				List<Contact> allContacts = contactService.listContacts();
				view.addObject("allContacts", allContacts);
				int length=allContacts.size();
				view.addObject("length", length);
				return view;
			}
	}

	@RequestMapping("/signUp")

	public ModelAndView saveUser(User user) {
		if(user.getUserId()!=0) {
		ModelAndView view = new ModelAndView("redirect:/login");

		view.addObject("user", new User());

		userService.addUser(user);

		return view;
		}
		else {
			ModelAndView view = new ModelAndView("signUp");
			return view;
		}
	}

	@RequestMapping("/Welcome")

	public ModelAndView userPortal() {

		ModelAndView view = new ModelAndView("login");

		view.addObject("user", new User());

		return view;
	}
	
	@RequestMapping("/WelcomeAdmin")

	public ModelAndView adminPortal() {

		ModelAndView view = new ModelAndView("adminLogin");

		view.addObject("admin", new Admin());

		return view;
	}
	
	
	
	

	@RequestMapping("/login")

	public ModelAndView login(User user) {

		ModelAndView view = new ModelAndView("login");
		List<User> allUsers = userDAO.findByUserIdAndPassword(user.getUserId(), user.getPassword());
		return view;
	}

	@RequestMapping("/checkUser")

	public ModelAndView checkUser(User user) {

		List<User> allUsers = userDAO.findByUserIdAndPassword(user.getUserId(), user.getPassword());

		if (!(allUsers.isEmpty())) {
			ModelAndView view = new ModelAndView("redirect:/contact");
			System.out.println(allUsers);
			return view;
		} else {
			ModelAndView view = new ModelAndView("login");
			return view;
		}
	}

	@RequestMapping("/searchUser")

	public ModelAndView searchContact(Contact contact, HttpServletRequest request) {

		String search="abc";
		String searchString="abc";
		search = (String) request.getParameter("search");
		searchString = (String) request.getParameter("searchString");
		System.out.println("########################"+search);
		System.out.println("########################"+searchString);
		if (search.equals("searchByName")) {
			ModelAndView view = new ModelAndView("userForm");

			view.addObject("contact", new Contact());

			List<Contact> allContacts = contactService.findByContactName(searchString);
			view.addObject("allContacts", allContacts);
			int length=allContacts.size();
			view.addObject("length", length);
			return view;
		} else if (search.equals("searchById")) {
			ModelAndView view = new ModelAndView("userForm");

			view.addObject("contact", new Contact());

			List<Contact> allContacts = contactService.findByContactId(Integer.parseInt(searchString));
			
			view.addObject("allContacts", allContacts);
			int length=allContacts.size();
			view.addObject("length", length);
			return view;
		}

		else if (search.equals("searchByNumber")) {
			ModelAndView view = new ModelAndView("userForm");

			view.addObject("contact", new Contact());

			List<Contact> allContacts =contactService.findByContactNumber((searchString));
			
			view.addObject("allContacts", allContacts);
			int length=allContacts.size();
			view.addObject("length", length);
			return view;
		} else {
			ModelAndView view = new ModelAndView("userForm");

			view.addObject("contact", new Contact());

			List<Contact> allContacts = contactService.listContacts();
			view.addObject("allContacts", allContacts);
			int length=allContacts.size();
			view.addObject("length", length);
			return view;
		}

	}
	
	
	@RequestMapping("/searchContact")

	public ModelAndView searchUserContact(Contact contact, HttpServletRequest request) {

		String search="abc";
		String searchString="abc";
		search = (String) request.getParameter("search");
		searchString = (String) request.getParameter("searchString");
		System.out.println("########################"+search);
		System.out.println("########################"+searchString);
		if (search.equals("searchByName")) {
			ModelAndView view = new ModelAndView("contactForm");

			view.addObject("contact", new Contact());

			List<Contact> allContacts = contactService.findByContactName(searchString);
			view.addObject("allContacts", allContacts);
			int length=allContacts.size();
			view.addObject("length", length);
			return view;
		} else if (search.equals("searchById")) {
			ModelAndView view = new ModelAndView("contactForm");

			view.addObject("contact", new Contact());

			List<Contact> allContacts = contactService.findByContactId(Integer.parseInt(searchString));
			
			view.addObject("allContacts", allContacts);
			int length=allContacts.size();
			view.addObject("length", length);
			return view;
		}

		else if (search.equals("searchByNumber")) {
			ModelAndView view = new ModelAndView("contactForm");

			view.addObject("contact", new Contact());

			List<Contact> allContacts =contactService.findByContactNumber((searchString));
			
			view.addObject("allContacts", allContacts);
			int length=allContacts.size();
			view.addObject("length", length);
			return view;
		} else {
			ModelAndView view = new ModelAndView("contactForm");

			view.addObject("contact", new Contact());

			List<Contact> allContacts = contactService.listContacts();
			view.addObject("allContacts", allContacts);
			int length=allContacts.size();
			view.addObject("length", length);
			return view;
		}

	}
	
	
	
	
	
	
	@RequestMapping("/admin")

	public ModelAndView userContactPortal(Contact contact) {
		if(contact.getContactId()!=0) {
			ModelAndView view = new ModelAndView("contactForm");

			view.addObject("contact", new Contact());

			List<Contact> allContacts = contactService.listContacts();
			view.addObject("allContacts", allContacts);
			System.out.println(allContacts);
			int length=allContacts.size();
			view.addObject("length", length);

			return view;
			}
			else {
				ModelAndView view = new ModelAndView("contactForm");
				List<Contact> allContacts = contactService.listContacts();
				view.addObject("allContacts", allContacts);
				int length=allContacts.size();
				view.addObject("length", length);
				return view;
			}
	}
	
	
	@RequestMapping("/checkAdmin")

	public ModelAndView checkAdmin(Admin admin) {

		List<Admin> allUsers = adminDAO.findByAdminNameAndPassword(admin.getAdminName(), admin.getPassword());
		System.out.println("33333333333333333333"+allUsers);
		if (!(allUsers.isEmpty())) {
			ModelAndView view = new ModelAndView("redirect:/admin");
			System.out.println(allUsers);
			return view;
		} else {
			ModelAndView view = new ModelAndView("redirect:/WelcomeAdmin");
			return view;
		}
	}

	
	
	

}