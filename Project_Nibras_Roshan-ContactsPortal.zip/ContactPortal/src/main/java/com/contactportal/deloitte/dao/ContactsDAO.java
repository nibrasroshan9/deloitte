package com.contactportal.deloitte.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.contactportal.deloitte.model.Contact;

@Repository
public interface ContactsDAO extends CrudRepository<Contact, Integer> {

	public List<Contact> findByContactName(String contactName);
	public List<Contact> findByContactId(int contactId);
	public List<Contact> findByContactNumber(String contactNumber);
}