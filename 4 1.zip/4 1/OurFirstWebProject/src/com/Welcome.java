package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Welcome
 */
public class Welcome extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Welcome() {
        super();
        // TODO Auto-generated constructor stub
    }
    int counter = 0;
	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		counter++;
		
		String uid = request.getParameter("Username");
		String pass = request.getParameter("password");
		response.getWriter().println("<h1>Welcome to my website, "+uid+"</h1>");
		response.getWriter().println("<h1>Your password is : "+pass+"</h1>");
		response.getWriter().println("<h1>You are visitor #"+counter+"</h1");
		response.getWriter().println("<h1><a href = 'Shop.html'>Shop</a></h1>");
		response.getWriter().println("<h1><a href = 'Customer>Customer</a></h1>");
	}

}
