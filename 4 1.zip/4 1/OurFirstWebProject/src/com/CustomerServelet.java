//package com;
import com.cms.deloitte.dao.impl.CustomerDAOImpl;
import com.cms.deloitte.model.Customer;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Customer
 */
public class CustomerServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustomerServelet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		int customerId = Integer.parseInt(request.getParameter("customerId"));
		String customerName = request.getParameter("customerName");
		String customerAddress = request.getParameter("customerAddress");
		int billAmount = Integer.parseInt(request.getParameter("billAmount"));
		response.getWriter().println("<h1>Your customer ID, "+customerId+"</h1>");
		response.getWriter().println("<h1>Your name is : "+customerName+"</h1>");
		response.getWriter().println("<h1>You are from "+customerAddress+"</h1>");
		response.getWriter().println("<h1>Your bill amount is : "+billAmount+"</h1>");

		Customer c = new Customer(customerId, customerName, customerAddress, billAmount);
		
		CustomerDAOImpl impl = new CustomerDAOImpl();
		if(impl.isCustomerExists(customerId)) {
			response.getWriter().println(customerId+" already exists");
		}
		else {
			impl.addCustomer(c);
			response.getWriter().println(customerName+" successfully saved");
		}
	}

}
