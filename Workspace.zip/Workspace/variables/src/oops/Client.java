package oops;

public class Client {

	public static void main(String[] args) {
		Employee emp = new Employee();
		emp.takeSalary();
		emp.printEmployeeDetails();
	}

}
