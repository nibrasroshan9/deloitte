package pack1;

public class A {
	public int i;
}
