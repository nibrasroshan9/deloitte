package pack1;

public class C {
	public void display() {
		A a = new A();
		a.i = 100;
		i = 100;
}
}