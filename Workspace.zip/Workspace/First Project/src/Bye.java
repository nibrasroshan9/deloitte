
public class Bye {
	public void sayThanks() {
		System.out.println("Thank you!");
	}
}
