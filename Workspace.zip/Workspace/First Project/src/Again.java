
public class Again {
	public void repeat() {
		System.out.println("Repeating");
	}
}
