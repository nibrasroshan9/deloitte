
public class Last {
	public void lastText() {
		System.out.println("This is the last text");
	}
}
