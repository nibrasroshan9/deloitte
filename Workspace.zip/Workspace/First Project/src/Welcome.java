import finance.Salary;

public class Welcome {

	public static void main(String[] args) {
		System.out.println("Welcome to Eclipse");
		
		  Bye bye = new Bye(); bye.sayThanks();
		  
		  Again ag = new Again(); ag.repeat();
		  
		  Last la = new Last(); la.lastText();
		  
		  Goodbye gd = new Goodbye(); gd.sayBye();
		 
		Salary s = new Salary();
		int sal = s.getSalary(40000, 8000);
		System.out.println(sal);
		
	}
}
