
public class Goodbye {
	public void sayBye() {
		System.out.println("Goodbye");
	}
}
