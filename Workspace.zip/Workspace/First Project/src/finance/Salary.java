package finance;

public class Salary {
	public int getSalary(int sal, int pf) {
		return (sal+pf);
	}
}
