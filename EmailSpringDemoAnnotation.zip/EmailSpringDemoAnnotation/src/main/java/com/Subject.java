package com;

public class Subject {
	private String caption;

	public Subject() {
		super();
	}

	public Subject(String subject) {
		super();
		this.caption = subject;
	}

	public String getSubject() {
		return caption;
	}

	public void setSubject(String subject) {
		this.caption = subject;
	}

	@Override
	public String toString() {
		return "Subject [subject=" + caption + "]";
	}
}
