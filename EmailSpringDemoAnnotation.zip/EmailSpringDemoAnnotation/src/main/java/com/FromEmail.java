package com;

public class FromEmail {
	private String fromName;
	private String fromEmailId;
	public FromEmail() {
		super();
	}
	public FromEmail(String fromName, String fromEmailId) {
		super();
		this.fromName = fromName;
		this.fromEmailId = fromEmailId;
	}
	public String getFromName() {
		return fromName;
	}
	public void setFromName(String fromName) {
		this.fromName = fromName;
	}
	public String getFromEmailId() {
		return fromEmailId;
	}
	public void setFromEmailId(String fromEmailId) {
		this.fromEmailId = fromEmailId;
	}
	@Override
	public String toString() {
		return "FromEmail [fromName=" + fromName + ", fromEmailId=" + fromEmailId + "]";
	}
}
