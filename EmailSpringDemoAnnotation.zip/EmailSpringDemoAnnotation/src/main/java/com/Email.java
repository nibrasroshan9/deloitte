package com;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.config.AppConfig;

public class Email {
	@Autowired
	private FromEmail from;
	@Autowired
	private ToEmail to;
	@Autowired
	private Subject sub;
	@Autowired
	private Body body;
	
	public Email() {
		super();
	}
	public Email(FromEmail from, ToEmail to, Subject sub, Body body) {
		super();
		this.from = from;
		this.to = to;
		this.sub = sub;
		this.body = body;
	}
	public FromEmail getFrom() {
		return from;
	}
	public void setFrom(FromEmail from) {
		this.from = from;
	}
	public ToEmail getTo() {
		return to;
	}
	public void setTo(ToEmail to) {
		this.to = to;
	}
	public Subject getSub() {
		return sub;
	}
	public void setSub(Subject sub) {
		this.sub = sub;
	}
	public Body getBody() {
		return body;
	}
	public void setBody(Body body) {
		this.body = body;
	}
	@Override
	public String toString() {
		return "Email [from=" + from + ", \n to=" + to + ",\n  sub=" + sub + ",\n  body=" + body + "]";
	}
}
