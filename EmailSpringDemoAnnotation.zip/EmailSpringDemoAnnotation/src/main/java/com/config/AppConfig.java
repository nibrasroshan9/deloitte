package com.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.Body;
import com.Email;
import com.FromEmail;
import com.Subject;
import com.ToEmail;

@Configuration
public class AppConfig {
	@Bean
	public Email getEmail() {
		return new Email();
	}
	@Bean
	public FromEmail getFromEmail() {
		return new FromEmail();
	}
	@Bean
	public ToEmail getToEmail() {
		return new ToEmail();
	}
	@Bean
	public Subject getSubject() {
		return new Subject();
	}
	@Bean
	public Body getBody() {
		return new Body();
	}
	
}
