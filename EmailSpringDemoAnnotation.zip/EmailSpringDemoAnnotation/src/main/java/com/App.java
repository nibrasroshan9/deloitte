package com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.config.AppConfig;

public class App {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		Email mail = context.getBean(Email.class);
		FromEmail from = context.getBean(FromEmail.class);
		ToEmail to = context.getBean(ToEmail.class);
		Subject sub = context.getBean(Subject.class);
		Body body = context.getBean(Body.class);
		
		body.setMessage("Hello Georgie");
		sub.setSubject("Eda naari");
		from.setFromName("Asphalt");
		from.setFromEmailId("Asphaltin@gameloft.com");
		to.setToName("George Thomas");
		to.setToEmailId("georgethomas@georgie.com");
		
		System.out.println(mail);
	}
}
