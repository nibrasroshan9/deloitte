billno =prompt("Enter bill no: ","00123");
billamount = prompt("Enter bill amount","5000")
ccardno=prompt("Enter credit card number : ","4442134565789844")
var today = new Date();
var lastdate = new Date();
lastdate.setDate(15);
if (lastdate>today){

	fine = 0
}
else{
	var day = 1000*60*60*24;
	x = (today - lastdate)/day;
	fine = x*50;
}
finalbill = parseInt(billamount)+parseInt(fine);
alert("Your total bill is : "+finalbill)