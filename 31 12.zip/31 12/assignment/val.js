function validation() {
	var username = document.getElementById("username").value;
	var spouse = document.getElementById("spousename").value;

	var errusername = document.getElementById("errusername");
	var errspouse = document.getElementById("errspouse");

	var i;
	if (username.length == 0) {
		errusername.innerHTML = "<font color=red>Please enter a valid username</font>";
		i = false;
		return false;
	} else {
		errusername.innerHTML = " ";
		i = true;
	}
	if (spouse.length == 0) {
		errspouse.innerHTML = "<font color=red>Please enter a valid spouse name</font>";
		i = false;
		return false;
	} else {
		errspouse.innerHTML = " ";
		i = true;
	}

	if (i == true) {
		change();
	}
}


function usergender(gender) {
	document.getElementById("acquire_gender").innerHTML = "<h2>Your gender is : "
			+ gender + "</h2>";
}

function usercomment(comments) {
	document.getElementById("acquire_comment").innerHTML = "<h2>Your comments are : "
			+ comments + "</h2>";
}

function change() {
	var name = document.getElementById("ack_name");
	var ack_gender = document.getElementById("ack_gender");
	var ack_like = document.getElementById("ack_like");

	var username = document.getElementById("username").value;

	name.innerHTML = "<h2>Congratulations you have entered the details with Name: "
			+ username + "</h2>";
	ack_gender.innerHTML = "<h2>Gender <h2>";
	ack_like.innerHTML = "<h2>Your Comment </h2>";

}
