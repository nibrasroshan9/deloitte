package collectionsdemo;

import java.util.LinkedHashSet;
import java.util.Set;

public class Demo2 {

	public static void main(String[] args) {
		Set names = new LinkedHashSet<>();
		
		names.add("Himanshu");
		names.add("Sachin");
		names.add("George");
		names.add("Subarna");
		names.add("Satya");
		names.add("Sumeet");
		names.add("Satya");
		
		System.out.println(names);
		names.add("Tufail");
		System.out.println(names);
		names.remove("Satya");
		System.out.println(names);
		System.out.println(names.size());
		System.out.println(names.isEmpty());
		
	}

}
