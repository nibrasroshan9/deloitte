package collectionsdemo;

import java.util.ArrayList;
import java.util.List;

public class Demo1 {

	public static void main(String[] args) {
		List names = new ArrayList();
		names.add("Himanshu");
		names.add("Sachin");
		names.add("George");
		names.add("Subarna");
		names.add("Satya");
		names.add("Sumeet");
		names.add("Satya");
		
		System.out.println(names);
		names.add(2,"Tufail");
		System.out.println(names);
		names.remove("Satya");
		System.out.println(names);
		System.out.println(names.size());
		System.out.println(names.isEmpty());

	}

}
