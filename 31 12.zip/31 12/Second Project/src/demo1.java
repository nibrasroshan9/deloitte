import java.util.InputMismatchException;
import java.util.Scanner;


public class demo1 {
	int num1, num2, result;
	Scanner in = new Scanner(System.in);
	
	public void display() {
		System.out.println("welcome to display");
		try {
			System.out.println("Enter first number");
			num1 = in.nextInt();
			System.out.println("Enter second number");
			num2 = in.nextInt();
			result = num1/num2;
			System.out.println(result);
		}
		catch (InputMismatchException e){
			System.out.println("Please enter a valid number");
		}
		catch (ArithmeticException e) {
			System.out.println("Please enter a non zero value as second number");
		}
	}
	public static void main(String[] args) {
		demo1 d = new demo1();
		d.display();
	}
}
