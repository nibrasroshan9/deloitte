import java.util.Scanner;

class InvalidAgeException extends RuntimeException{
	public InvalidAgeException() {
		
	}
	public InvalidAgeException(String msg) {
		super(msg);
	}
}

class NewYearParty{
	int minAge = 16;
	Scanner in = new Scanner(System.in);
	int age;
	public void enterClub() throws InvalidAgeException{
		System.out.println("Please enter your age : ");
		age = in.nextInt();
		if (age<minAge) {
			throw new InvalidAgeException("Underage. Come back in a few years.");
		}
		else
			System.out.println("Welcome to the Club");
	}
}
public class Demo5 {

	public static void main(String[] args) {
		NewYearParty party = new NewYearParty();
		try {
			party.enterClub();
		}
		catch (Exception e){
			System.out.println("Underage. Please leave.");
		}
		System.out.println("Happy New Year");

}
}
