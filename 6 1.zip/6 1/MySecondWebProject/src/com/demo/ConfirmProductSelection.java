package com.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ConfirmProductSelection
 */
@WebServlet("/ConfirmProductSelection")
public class ConfirmProductSelection extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ConfirmProductSelection() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		String selectedItems[] = request.getParameterValues("item");
		PrintWriter out = response.getWriter();
		
		HttpSession session = request.getSession();
		String str = (String)session.getAttribute("currentUser");
		response.getWriter().println("<br/>"+str+"<br/>");
		
		if(selectedItems == null) {
			response.getWriter().println("<h1>Select at least one item to proceed</h1>");
			response.getWriter().println("<a href='Item.html'>Go back</a>");
		}
		else {
			response.getWriter().println("You chose the following;");
			for (String s:selectedItems) {
				out.println(s);
				out.print("<br/>");
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
