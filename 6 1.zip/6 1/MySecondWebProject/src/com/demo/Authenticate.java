package com.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Authenticate
 */
@WebServlet("/Authenticate")
public class Authenticate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Authenticate() {
        super();
        // TODO Auto-generated constructor stub
    }

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	// TODO Auto-generated method stub
    	//super.service(request, response);
    	String username = request.getParameter("username");
    	String password = request.getParameter("password");
    	PrintWriter out = response.getWriter();
    	
    	HttpSession session = request.getSession();
    	session.setAttribute("currentUser", username);
    	
    	Cookie allCookies[] = request.getCookies();
    	boolean visited = false;
    	if(allCookies != null) {
    		for(Cookie c : allCookies) {
    			if(c.getName().equals(username)) {
    				visited = true;
    				break;
    			}
    		}
    	}
    	if(visited) {
    		out.println("Already visited");
    	}
    	else {
    		out.println("First time");
    		Cookie cookie = new Cookie(username, username);
    		response.addCookie(cookie);
    	}
    	
    	out.println("<h1><form action='Admin'></h1>");
    	out.println("<h1>Wife Name : <input type='text' name='wifeName'></h1>");
    	out.println("<input type='hidden' name='username' value="+username+">");
    	out.println("<input type='submit' value='Enter'>");
    	out.println("</form>");

    	
    	out.println("<h2>"+username+", you are authenticated<h2>");
    	if(username.toLowerCase().equals("admin")) {
    		RequestDispatcher dispatch = request.getRequestDispatcher("Admin");
    		dispatch.include(request, response);
    	}
    	else if(username.toLowerCase().equals("guest")) {
    		RequestDispatcher dispatch = request.getRequestDispatcher("Guest");
    		dispatch.include(request, response);
    	}
    	else {
    		RequestDispatcher dispatch = request.getRequestDispatcher("Other");
    		dispatch.include(request, response);
    	}
    }

}
