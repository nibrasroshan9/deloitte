package com.ex1_2;

import java.util.Scanner;

public class EmployeeMain {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter number of employees");
		int num = in.nextInt();
		EmployeeVo[] employees = new EmployeeVo[num];
		for(int i=0; i<num; i++) {
			EmployeeVo e = new EmployeeVo();
			e = e.accept();
			new EmployeeBo().callIncomeTax(e);
			employees[i] = e;
		}
		for(int j=0; j<num; j++) {
			System.out.println(employees[j]);
		}
		System.out.println("Sorting");
		
	}

}
