package com.ex1_2;

public class EmployeeBo {
	
	public void callIncomeTax(EmployeeVo e) {
		int annualIncome = e.getAnnualIncome();
		if(annualIncome<=250000) {
			int temp = 0;
			e.setIncomeTax(temp);
		}
		else if(annualIncome<=500000) {
			int temp = ((annualIncome-250000)*(5/100));
			e.setIncomeTax(temp);
		}
		else if(annualIncome<=1000000) {
			int temp = (25000+annualIncome-500000)*(20/100);
			e.setIncomeTax(temp);
		}
		else {
			int temp = (112500+annualIncome-1000000)*(30/100);
			e.setIncomeTax(temp);
		}
		System.out.println("Income tax is "+e.getIncomeTax());

	}

}
