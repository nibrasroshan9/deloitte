package com.ex1_1;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Arithmetic[] operations = {new Addition(), new Subtraction(), new Multiplication(), new Division()};
		Scanner scanner = new Scanner(System.in);
		System.out.println("Please enter your choice: ");
		System.out.println("1.Add");
		System.out.println("2.Subtract");
		System.out.println("3.Multiply");
		System.out.println("4.Divide");
		int choice = (scanner.nextInt())-1;
		System.out.println("Please enter first number");
		int num1 = scanner.nextInt();
		System.out.println("Please enter second number");
		int num2 = scanner.nextInt();
		operations[choice].setNum1(num1);
		operations[choice].setNum2(num2);
		int result = operations[choice].calculate();
		scanner.close();
		System.out.println("Result is: "+ result);
		
	}
}